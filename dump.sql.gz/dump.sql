-- Adminer 4.8.0 PostgreSQL 9.5.24 dump

DROP TABLE IF EXISTS "classroom";
CREATE TABLE "public"."classroom" (
    "id" integer NOT NULL,
    "name" character varying(255) NOT NULL,
    "is_active" boolean NOT NULL,
    "created_at" timestamp(0) NOT NULL,
    CONSTRAINT "classroom_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

INSERT INTO "classroom" ("id", "name", "is_active", "created_at") VALUES
(1,	'first',	't',	'2021-03-28 16:43:23'),
(3,	'third',	't',	'2021-03-28 16:44:09'),
(4,	'fourth',	'f',	'2021-03-28 16:44:28'),
(2,	'second',	'f',	'2021-03-28 16:43:51'),
(6,	'aaaa',	't',	'2021-03-28 18:46:52');

DROP TABLE IF EXISTS "doctrine_migration_versions";
CREATE TABLE "public"."doctrine_migration_versions" (
    "version" character varying(191) NOT NULL,
    "executed_at" timestamp(0),
    "execution_time" integer,
    CONSTRAINT "doctrine_migration_versions_pkey" PRIMARY KEY ("version")
) WITH (oids = false);

INSERT INTO "doctrine_migration_versions" ("version", "executed_at", "execution_time") VALUES
('DoctrineMigrations\Version20210328124312',	'2021-03-28 18:07:44',	26);

-- 2021-03-28 19:29:22.710015+03
